package com.faculdade.repository.impl

import com.faculdade.repository.`interface`.CadastroProdutosRepositoryQueries
import org.springframework.data.mongodb.core.MongoTemplate

class CadastroProdutoRepositoryImpl (private val mongoTemplate: MongoTemplate) : CadastroProdutosRepositoryQueries