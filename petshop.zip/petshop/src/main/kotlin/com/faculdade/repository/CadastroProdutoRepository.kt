package com.faculdade.repository
import com.faculdade.model.LojaMongo
import com.faculdade.repository.`interface`.CadastroProdutosRepositoryQueries
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Repository

@Repository
interface CadastroProdutoRepository : CrudRepository<LojaMongo, Long>, CadastroProdutosRepositoryQueries {

    fun findByCategoria(categoria: String): List<LojaMongo>
}
