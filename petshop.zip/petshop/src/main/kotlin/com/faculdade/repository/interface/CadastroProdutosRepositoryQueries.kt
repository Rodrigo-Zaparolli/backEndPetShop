package com.faculdade.repository.`interface`

import org.springframework.stereotype.Repository

@Repository
interface CadastroProdutosRepositoryQueries
