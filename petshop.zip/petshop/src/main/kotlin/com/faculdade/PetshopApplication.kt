package com.faculdade

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication


@SpringBootApplication
class PetshopApplication

fun main(args: Array<String>) {
	//runApplication<PetshopApplication>(*args)
	try {
		runApplication<PetshopApplication>(*args)
	} catch (e: Exception) {
		e.printStackTrace()
	}

}
