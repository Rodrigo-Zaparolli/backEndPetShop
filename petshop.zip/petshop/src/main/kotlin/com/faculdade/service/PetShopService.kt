package com.faculdade.service

import com.faculdade.converter.ProdutoConverter
import com.faculdade.dto.CadastroProdutosDto
import com.faculdade.dto.RespondeProdutosDTO
import com.faculdade.repository.CadastroProdutoRepository
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Service
import org.springframework.util.StringUtils

@Service
class PetShopService (
    private val repository: CadastroProdutoRepository,
    private val converter: ProdutoConverter
){

    fun cadastroProdutos(produtosDto: CadastroProdutosDto): ResponseEntity<String> {
        val produto = repository.findById(produtosDto.idProduto);
        if(produto.isPresent){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Produto ja cadastrado")
        }else{
            repository.save(converter.toCadastroLoja(produtosDto))
            return ResponseEntity.status(HttpStatus.ACCEPTED).body("Cadastro Realizado com Sucesso")
        }
    }
    //retorna lista dos produtos ordenados de forma crescente
    fun listar(): List<RespondeProdutosDTO> {
        var lista = repository.findAll().map(converter::toResponseProdutos)
        return lista.sortedBy { it.idProduto }
    }

    fun deletar(idProduto: Long) : ResponseEntity<String> {
        repository.deleteById(idProduto)
        return ResponseEntity.status(HttpStatus.ACCEPTED).body("Produto excluído com Sucesso")
    }

    fun buscarPorId(idProduto: Long): RespondeProdutosDTO {
        val produto = repository.findById(idProduto);
        return converter.toResponseProdutos(produto.get())
    }

    fun buscarPorCategoria(categoria: String): List<RespondeProdutosDTO> {
        val categoria = repository.findByCategoria(categoria)
        return categoria.map(converter:: toResponseProdutos)
    }


    fun atualizarProduto(cadastroProdutosDto: CadastroProdutosDto): ResponseEntity<String>  {
        val produto = repository.findById(cadastroProdutosDto.idProduto).get().copy(
            id = cadastroProdutosDto.idProduto,
            nomeProduto = cadastroProdutosDto.nomeProduto,
            valorProduto = cadastroProdutosDto.valorProduto,
            categoria = cadastroProdutosDto.categoria,
            dataValidade = cadastroProdutosDto.dataValidade,
            marcaProduto = cadastroProdutosDto.marcaProduto,
            observacao = cadastroProdutosDto.observacao
        )

        repository.save(produto)

        return ResponseEntity.status(HttpStatus.ACCEPTED).body("Cadastro alterado com Sucesso")
    }
}