package com.faculdade.controller

import com.faculdade.dto.CadastroProdutosDto
import com.faculdade.dto.RespondeProdutosDTO
import com.faculdade.service.PetShopService
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("api/petshop")
class PetShopController (
    val petShopService: PetShopService
){

    //cadastro petshop
    @PostMapping
    fun cadastroPetshop(@RequestBody cadastroProdutosDto: CadastroProdutosDto): ResponseEntity<String>{
        return petShopService.cadastroProdutos(cadastroProdutosDto)
    }

    //lista todos produtos
    @GetMapping("/listar")
    fun listar(): List<RespondeProdutosDTO> {
        return petShopService.listar()
    }
    //lista por ID
    @GetMapping("/listarId/{id}")
    fun buscarPorId(@PathVariable id: Long): RespondeProdutosDTO {
        return petShopService.buscarPorId(id)
    }

    //lista por categoria
    @GetMapping("/listarCategoria/{categoria}")
    fun buscarPorCategoria(@PathVariable categoria: String): List<RespondeProdutosDTO> {
        return petShopService.buscarPorCategoria(categoria)
    }

    //alterar produtos
    @PutMapping("/atualizarProduto")
    fun alterarProduto(@RequestBody cadastroProdutosDto: CadastroProdutosDto): ResponseEntity<String>  {
        return petShopService.atualizarProduto(cadastroProdutosDto)
    }

    //deleta um produto pelo ID
    @DeleteMapping("/{idProduto}")
    fun deletar(@PathVariable idProduto: Long) : ResponseEntity<String> {
        return petShopService.deletar(idProduto)
    }
}