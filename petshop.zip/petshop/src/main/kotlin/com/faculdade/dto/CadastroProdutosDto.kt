package com.faculdade.dto


import java.math.BigDecimal



data class CadastroProdutosDto (
    val idProduto: Long,
    val nomeProduto: String,
    val valorProduto: BigDecimal,
    val categoria: String,
    val dataValidade: String,
    val marcaProduto: String,
    val observacao: String
)