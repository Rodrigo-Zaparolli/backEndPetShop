package com.faculdade.dto

import java.math.BigDecimal

class RespondeProdutosDTO(
    val idProduto: Long? = null,
    val nomeProduto: String,
    val valorProduto: BigDecimal,
    val categoria: String,
    val dataValidade: String,
    val marcaProduto: String,
    val observacao: String
)

