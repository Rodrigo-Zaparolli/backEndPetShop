package com.faculdade.converter

import com.faculdade.dto.CadastroProdutosDto
import com.faculdade.dto.RespondeProdutosDTO
import com.faculdade.model.LojaMongo
import org.springframework.stereotype.Component

@Component
class ProdutoConverter {

    fun toCadastroLoja(dto: CadastroProdutosDto): LojaMongo {
        return LojaMongo(
            id = dto.idProduto,
            nomeProduto = dto.nomeProduto,
            valorProduto = dto.valorProduto,
            categoria = dto.categoria,
            dataValidade = dto.dataValidade,
            marcaProduto = dto.marcaProduto,
            observacao = dto.observacao
        )
    }

    fun toResponseProdutos(loja: LojaMongo): RespondeProdutosDTO {
        return RespondeProdutosDTO(
            idProduto = loja.id,
            nomeProduto = loja.nomeProduto,
            valorProduto = loja.valorProduto,
            categoria = loja.categoria,
            dataValidade = loja.dataValidade,
            marcaProduto = loja.marcaProduto,
            observacao = loja.observacao
        )
    }
}
