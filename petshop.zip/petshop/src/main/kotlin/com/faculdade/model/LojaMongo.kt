package com.faculdade.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import org.springframework.data.mongodb.core.mapping.Field
import java.math.BigDecimal

@Document("dadosLojaMongo")
data class LojaMongo(

    @Id
    @Field("id")
    val id: Long,
    @Field("nomeProduto")
    var nomeProduto: String = "",
    @Field("valorProduto")
    var valorProduto: BigDecimal = BigDecimal.ZERO,
    @Field("categoria")
    var categoria: String = "",
    @Field("dataValidade")
    var dataValidade: String,
    @Field("marcaProduto")
    var marcaProduto: String = "",
    @Field("observacao")
    var observacao: String = "",
)